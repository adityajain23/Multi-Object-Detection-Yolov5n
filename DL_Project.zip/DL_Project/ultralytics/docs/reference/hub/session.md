# HUBTrainingSession
---
:::ultralytics.hub.session.HUBTrainingSession
<br><br>
