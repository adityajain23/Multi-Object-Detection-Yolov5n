# BaseDataset
---
:::ultralytics.yolo.data.base.BaseDataset
<br><br>
