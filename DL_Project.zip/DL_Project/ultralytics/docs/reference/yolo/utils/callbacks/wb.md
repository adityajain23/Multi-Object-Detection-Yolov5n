# on_pretrain_routine_start
---
:::ultralytics.yolo.utils.callbacks.wb.on_pretrain_routine_start
<br><br>

# on_fit_epoch_end
---
:::ultralytics.yolo.utils.callbacks.wb.on_fit_epoch_end
<br><br>

# on_train_epoch_end
---
:::ultralytics.yolo.utils.callbacks.wb.on_train_epoch_end
<br><br>

# on_train_end
---
:::ultralytics.yolo.utils.callbacks.wb.on_train_end
<br><br>
