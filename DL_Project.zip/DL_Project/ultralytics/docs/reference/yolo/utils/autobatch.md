# check_train_batch_size
---
:::ultralytics.yolo.utils.autobatch.check_train_batch_size
<br><br>

# autobatch
---
:::ultralytics.yolo.utils.autobatch.autobatch
<br><br>
