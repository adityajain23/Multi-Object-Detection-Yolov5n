# Bboxes
---
:::ultralytics.yolo.utils.instance.Bboxes
<br><br>

# Instances
---
:::ultralytics.yolo.utils.instance.Instances
<br><br>

# _ntuple
---
:::ultralytics.yolo.utils.instance._ntuple
<br><br>
