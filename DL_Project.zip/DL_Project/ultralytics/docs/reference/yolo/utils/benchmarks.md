# benchmark
---
:::ultralytics.yolo.utils.benchmarks.benchmark
<br><br>
