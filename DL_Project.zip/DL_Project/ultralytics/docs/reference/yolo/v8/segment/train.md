# SegmentationTrainer
---
:::ultralytics.yolo.v8.segment.train.SegmentationTrainer
<br><br>

# SegLoss
---
:::ultralytics.yolo.v8.segment.train.SegLoss
<br><br>

# train
---
:::ultralytics.yolo.v8.segment.train.train
<br><br>
