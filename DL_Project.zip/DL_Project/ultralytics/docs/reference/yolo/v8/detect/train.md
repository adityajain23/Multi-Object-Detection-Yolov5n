# DetectionTrainer
---
:::ultralytics.yolo.v8.detect.train.DetectionTrainer
<br><br>

# Loss
---
:::ultralytics.yolo.v8.detect.train.Loss
<br><br>

# train
---
:::ultralytics.yolo.v8.detect.train.train
<br><br>
