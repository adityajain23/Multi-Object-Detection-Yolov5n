# BaseTensor
---
:::ultralytics.yolo.engine.results.BaseTensor
<br><br>

# Results
---
:::ultralytics.yolo.engine.results.Results
<br><br>

# Boxes
---
:::ultralytics.yolo.engine.results.Boxes
<br><br>

# Masks
---
:::ultralytics.yolo.engine.results.Masks
<br><br>
