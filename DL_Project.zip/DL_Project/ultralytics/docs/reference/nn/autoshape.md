# AutoShape
---
:::ultralytics.nn.autoshape.AutoShape
<br><br>

# Detections
---
:::ultralytics.nn.autoshape.Detections
<br><br>
