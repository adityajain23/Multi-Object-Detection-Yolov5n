import torch
import torch.nn as nn
from ultralytics.nn.modules import Conv


class Addition(nn.Module):

    def __init__(self, num_add=2):
        super().__init__()
        self.num_add = num_add

    def forward(self, x):
        # print(x[0].shape, x[1].shape)
        out = torch.add(x[0], x[1])
        # print(x.shape)
        return out


class InceptionModule(nn.Module):
    def __init__(self, c_in, c_out):
        super().__init__()
        c_branch = c_out // 4
        self.branch1 = Conv(c_in, c_branch, k=1, s=1)
        self.branch2 = nn.Sequential(
            Conv(c_in, c_branch, k=1, s=1),
            Conv(c_branch, c_branch, k=3, s=1, p=1),
        )
        self.branch3 = nn.Sequential(
            Conv(c_in, c_branch, k=1, s=1),
            Conv(c_branch, c_branch, k=5, s=1, p=2),
        )
        self.branch4 = nn.Sequential(
            nn.MaxPool2d(kernel_size=3, padding=1, stride=1),
            Conv(c_in, c_branch, k=1)
        )

    def forward(self, x):
        branches = (self.branch1, self.branch2, self.branch3, self.branch4)
        return torch.cat([branch(x) for branch in branches], 1)
